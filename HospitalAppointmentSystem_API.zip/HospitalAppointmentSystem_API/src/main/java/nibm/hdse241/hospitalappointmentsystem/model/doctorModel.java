package nibm.hdse241.hospitalappointmentsystem.model;

import java.util.List;

public class doctorModel {
    private Long id;
    private String profession;
    private String specialization;
    private List<String> availableTimeSlots;
}
