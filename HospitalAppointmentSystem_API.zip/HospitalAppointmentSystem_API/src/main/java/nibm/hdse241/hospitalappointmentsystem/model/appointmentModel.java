package nibm.hdse241.hospitalappointmentsystem.model;

public class appointmentModel {
    private int id;
    private String patientIndex;
    private String patientName;
    private String doctorName;
    private String patientMobile;
    private String patientEmail;
    private String appointmentTime;
    private String appointmentDate;
    private boolean appointmentStatus;
}
