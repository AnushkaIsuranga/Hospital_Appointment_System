package nibm.hdse241.hospitalappointmentsystem.model;

public class userModel {
    private Long id;
    private String username;
    private String password;
    private String fullName;
    private String email;
    private String role;
    private String address;
    private String phone;
    private String birthday;
}
