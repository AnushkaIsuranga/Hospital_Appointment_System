package nibm.hdse241.hospitalappointmentsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalAppointmentSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
